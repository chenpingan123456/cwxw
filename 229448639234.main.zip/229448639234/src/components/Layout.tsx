import { ReactNode, useContext } from 'react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTheme } from '@/hooks/useTheme';
import { AuthContext } from '@/App';
import { motion } from "framer-motion";


interface LayoutProps {
  children: ReactNode;
  title: string;
  showBack?: boolean;
  showFooter?: boolean;
}

export default function Layout({ children, title, showBack = true, showFooter = true }: LayoutProps) {
  const navigate = useNavigate();
  const { isDark, toggleTheme } = useTheme();

  return (
    <div className={`min-h-screen flex flex-col ${isDark ? 'bg-gray-900 text-gray-100' : 'bg-gray-50 text-gray-800'} transition-colors duration-200`}>
      {/* 统一导航栏 */}
      <header className={`${isDark ? 'bg-gray-800/90 border-gray-700' : 'bg-white/90 border-gray-100'} backdrop-blur-sm py-4 px-6 sticky top-0 z-50 border-b transition-colors duration-200`}>
        <style jsx global>{`
          input, select, textarea {
            ${isDark ? `
              background-color: #1f2937;
              border-color: #4b5563;
              color: #f3f4f6;
            ` : `
              background-color: white;
              border-color: #e5e7eb;
              color: #111827;
            `}
          }
          input:focus, select:focus, textarea:focus {
            ${isDark ? `
              border-color: #60a5fa;
              box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.3);
            ` : `
              border-color: #3b82f6;
              box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.3);
            `}
          }
        `}</style>
         <div className="max-w-6xl mx-auto flex justify-between items-center">
           <div className="flex items-center space-x-2">
             {showBack && (
               <button 
                 onClick={() => navigate('/')}
                 className={`${isDark ? 'text-blue-400 hover:text-blue-300' : 'text-blue-500 hover:text-blue-700'}`}
               >
                 <i className="fa-solid fa-arrow-left mr-2"></i>
                 返回首页
               </button>
             )}
           </div>
           <h1 className="text-xl font-bold">{title}</h1>
           <div className="flex items-center space-x-4">
             <button 
               onClick={toggleTheme}
               className={`p-2 rounded-lg ${isDark ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-200 hover:bg-gray-300'} transition-colors duration-200`}
               aria-label={`切换至${isDark ? '亮色' : '暗色'}主题`}
             >
               <i className={`fa-solid ${isDark ? 'fa-sun text-yellow-300' : 'fa-moon text-gray-600'}`}></i>
             </button>
           </div>
         </div>
      </header>

      {/* 主内容区域 */}
      <main className="flex-grow max-w-6xl w-full mx-auto py-8 px-4 md:px-6">
        {children}
      </main>

      {/* 底部导航栏 */}
      {showFooter && (
        <motion.footer 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
          className={`${isDark ? 'bg-gray-800/90 border-gray-700' : 'bg-white/90 border-gray-100'} backdrop-blur-sm py-4 px-6 border-t transition-colors duration-200`}
        >
          <div className="max-w-6xl mx-auto text-center">
            <p className={`${isDark ? 'text-gray-500' : 'text-gray-400'} text-xs`}>© 2025 财务助手. 保留所有权利.</p>
          </div>
        </motion.footer>
      )}
    </div>
  );
}