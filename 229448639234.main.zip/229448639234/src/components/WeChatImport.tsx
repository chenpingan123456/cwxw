import { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { createWorker } from 'tesseract.js';
import Papa from 'papaparse';

interface Transaction {
  id: string;
  amount: number;
  type: 'income' | 'expense';
  category: string;
  date: string;
  note: string;
  isRecurring: boolean;
}

interface WeChatImportProps {
  onImport: (transactions: Transaction[]) => void;
}

export default function WeChatImport({ onImport }: WeChatImportProps) {
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  const handleFileImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    
    try {
      if (file.name.endsWith('.csv')) {
        // 解析CSV文件
        Papa.parse(file, {
          complete: (results) => {
            const transactions = parseWeChatCSV(results.data);
            onImport(transactions);
          },
          header: true,
          skipEmptyLines: true
        });
      } else {
        toast.error('仅支持CSV格式文件');
      }
    } catch (error) {
      toast.error('文件解析失败');
      console.error(error);
    } finally {
      setIsProcessing(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleImageImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    
    try {
      const worker = await createWorker();
      await worker.loadLanguage('chi_sim+eng');
      await worker.initialize('chi_sim+eng');
      
      const { data } = await worker.recognize(file);
      const transactions = parseWeChatText(data.text);
      onImport(transactions);
      
      await worker.terminate();
    } catch (error) {
      toast.error('图片识别失败');
      console.error(error);
    } finally {
      setIsProcessing(false);
      if (imageInputRef.current) imageInputRef.current.value = '';
    }
  };

  // 解析微信账单CSV数据
  const parseWeChatCSV = (data: any[]): Transaction[] => {
    return data
      .filter(row => row['交易时间'] && row['金额(元)'])
      .map(row => {
        const amount = parseFloat(row['金额(元)']);
        const isIncome = amount > 0;
        
        return {
          id: `wc-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          amount: Math.abs(amount),
          type: isIncome ? 'income' : 'expense',
          category: row['交易类型'] || (isIncome ? '收入' : '支出'),
          date: row['交易时间'] || new Date().toISOString().split('T')[0],
          note: row['商品'] || '',
          isRecurring: false
        };
      });
  };

  // 解析微信账单图片文本
  const parseWeChatText = (text: string): Transaction[] => {
    const lines = text.split('\n').filter(line => line.trim());
    const transactions: Transaction[] = [];
    
    lines.forEach(line => {
      // 尝试匹配微信账单格式
      const match = line.match(/(\d{4}-\d{2}-\d{2})[\s\S]+?([\d,]+\.\d{2})[\s\S]+?(收入|支出)/);
      if (match) {
        const amount = parseFloat(match[2].replace(',', ''));
        transactions.push({
          id: `wc-img-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          amount,
          type: match[3] === '收入' ? 'income' : 'expense',
          category: match[3] === '收入' ? '收入' : '支出',
          date: match[1],
          note: '',
          isRecurring: false
        });
      }
    });
    
    return transactions;
  };

  return (
    <div className="relative">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="flex gap-3"
      >
        <motion.button 
          className="text-base bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white px-4 py-2 rounded-lg flex items-center shadow-md"
          onClick={() => fileInputRef.current?.click()}
          disabled={isProcessing}
          whileHover={{ scale: 1.05, boxShadow: "0 5px 15px rgba(59, 130, 246, 0.4)" }}
          whileTap={{ scale: 0.98 }}
        >
          {isProcessing ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.2 }}
              className="flex items-center"
            >
              <i className="fa-solid fa-spinner fa-spin mr-2"></i>
              处理中...
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.2 }}
              className="flex items-center"
            >
              <i className="fa-solid fa-file-csv mr-2"></i>
              导入CSV账单
            </motion.div>
          )}
        </motion.button>

        <motion.button 
          className="text-base bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white px-4 py-2 rounded-lg flex items-center shadow-md"
          onClick={() => imageInputRef.current?.click()}
          disabled={isProcessing}
          whileHover={{ scale: 1.05, boxShadow: "0 5px 15px rgba(16, 185, 129, 0.4)" }}
          whileTap={{ scale: 0.98 }}
        >
          {isProcessing ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.2 }}
              className="flex items-center"
            >
              <i className="fa-solid fa-spinner fa-spin mr-2"></i>
              处理中...
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.2 }}
              className="flex items-center"
            >
              <i className="fa-solid fa-image mr-2"></i>
              识别图片账单
            </motion.div>
          )}
        </motion.button>
      </motion.div>
      
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileImport}
        accept=".csv"
        className="hidden"
      />
      
      <input
        type="file"
        ref={imageInputRef}
        onChange={handleImageImport}
        accept="image/*"
        className="hidden"
      />
    </div>
  );
}