import { createContext, useState } from 'react';
import { Routes, Route, useLocation } from "react-router-dom";
import Home from "@/pages/Home";
import Accounting from "@/pages/Accounting";
import Dashboard from "@/pages/Dashboard";
import Budget from "@/pages/Budget";
import FoodRoulette from "@/pages/FoodRoulette";
import { AnimatePresence, motion } from "framer-motion";

export const AuthContext = createContext({
  isAuthenticated: false,
  setIsAuthenticated: (value: boolean) => {},
  username: '',
  setUsername: (value: string) => {},
  avatar: '',
  setAvatar: (value: string) => {},
  salary: 0,
  setSalary: (value: number) => {}
});

export default function App() {
  const location = useLocation();
  
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [username, setUsername] = useState('');
  const [avatar, setAvatar] = useState('');
  const [salary, setSalary] = useState(0);

  return (
    <AuthContext.Provider value={{
      isAuthenticated,
      setIsAuthenticated,
      username,
      setUsername,
      avatar,
      setAvatar,
      salary,
      setSalary
    }}>
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Home />
          </motion.div>
        } />
        <Route path="/accounting" element={
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Accounting />
          </motion.div>
        } />
        <Route path="/dashboard" element={
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Dashboard />
          </motion.div>
        } />
        <Route path="/budget" element={
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Budget />
          </motion.div>
        } />
        <Route path="/food-roulette" element={
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <FoodRoulette />
          </motion.div>
        } />
      </Routes>
    </AnimatePresence>
    </AuthContext.Provider>
  );
}
