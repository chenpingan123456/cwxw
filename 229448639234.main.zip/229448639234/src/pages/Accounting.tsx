import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import Layout from '@/components/Layout';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import WeChatImport from '@/components/WeChatImport';
import { validateTransactionData, formatExportFilename } from '@/lib/utils';
import Papa from 'papaparse';

interface Transaction {
  id: string;
  amount: number;
  type: 'income' | 'expense';
  category: string;
  subcategory: string;
  date: string;
  note: string;
  isRecurring: boolean;
  tags: string[];
}

type ViewType = 'transactions' | 'stats' | 'budget';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

  // 分类和子分类映射
  const CATEGORIES = {
    '餐饮': ['早餐', '午餐', '晚餐', '下午茶', '零食', '饮料', '外卖', '食材采购'],
    '交通': ['公共交通', '打车', '加油', '停车费', '维修保养', '车险', '车辆年检', '洗车'],
    '购物': ['衣物', '日用品', '电子产品', '家居用品', '化妆品', '珠宝首饰', '运动装备'],
    '娱乐': ['电影', '游戏', '运动', '旅游', '音乐会', '演出', '游乐场', 'KTV'],
    '住房': ['房租', '房贷', '水电煤', '物业费', '家具家电', '维修', '装修', '保洁'],
    '医疗': ['门诊', '药品', '体检', '保险', '牙科', '眼科', '理疗', '保健品'],
    '教育': ['学费', '书籍', '培训', '文具', '网课', '考试费', '学习软件', '家教'],
    '通讯': ['话费', '网费', '设备', '会员订阅', '云服务', '软件购买'],
    '投资': ['股票', '基金', '理财', '保险', '数字货币', '定期存款'],
    '宠物': ['宠物食品', '宠物医疗', '宠物用品', '宠物美容', '宠物保险'],
    '个人发展': ['健身', '课程', '书籍', '心理咨询', '技能培训'],
    '其他': ['捐赠', '礼品', '意外支出', '罚款', '手续费', '税费'],
    '收入': ['工资', '奖金', '投资', '兼职', '其他收入', '租金', '分红', '退款']
  };

export default function Accounting() {
  const navigate = useNavigate();
  const [transactions, setTransactions] = useLocalStorage<Transaction[]>('transactions', []);
  const [activeView, setActiveView] = useState<ViewType>('transactions');
  const [filterCategory, setFilterCategory] = useState('');
  const [newTag, setNewTag] = useState('');
  
  const filteredTransactions = transactions.filter(t => 
    !filterCategory || t.category === filterCategory
  );
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTransaction, setNewTransaction] = useState<Transaction>({
    id: '',
    amount: 0,
    type: 'expense',
    category: '餐饮',
    subcategory: '午餐',
    date: new Date().toISOString().split('T')[0],
    note: '',
    isRecurring: false,
    tags: []
  });
  const amountInputRef = useRef<HTMLInputElement>(null);

  // 按类别统计支出数据
  const categoryData = transactions
    .filter(t => t.type === 'expense')
    .reduce((acc, t) => {
      const existing = acc.find(item => item.category === t.category);
      if (existing) {
        existing.amount += t.amount;
      } else {
        acc.push({ 
          category: t.category, 
          amount: t.amount,
          color: [
            '#3b82f6', '#10b981', '#f59e0b', 
            '#ef4444', '#8b5cf6', '#ec4899'
          ][acc.length % 6]
        });
      }
      return acc;
    }, [] as {category: string, amount: number, color: string}[])
    .sort((a, b) => b.amount - a.amount);

  // 按子分类统计支出数据
  const subcategoryData = transactions
    .filter(t => t.type === 'expense')
    .reduce((acc, t) => {
      const existing = acc.find(item => item.subcategory === t.subcategory);
      if (existing) {
        existing.amount += t.amount;
      } else {
        acc.push({ 
          category: t.category,
          subcategory: t.subcategory, 
          amount: t.amount 
        });
      }
      return acc;
    }, [] as {category: string, subcategory: string, amount: number}[])
    .sort((a, b) => b.amount - a.amount);

  // 按月份统计收支数据
  const monthlyData = transactions.reduce((acc, t) => {
    const month = t.date.split('-').slice(0, 2).join('-');
    const existing = acc.find(item => item.month === month);
    if (existing) {
      existing[t.type] += t.amount;
      existing.total += t.amount;
    } else {
      acc.push({
        month,
        income: t.type === 'income' ? t.amount : 0,
        expense: t.type === 'expense' ? t.amount : 0,
        total: t.amount
      });
    }
    return acc;
  }, [] as {month: string, income: number, expense: number, total: number}[])
  .sort((a, b) => a.month.localeCompare(b.month));

  // 按周统计收支数据
  const weeklyData = transactions.reduce((acc, t) => {
    const date = new Date(t.date);
    const week = `第${getWeekNumber(date)}周`;
    const existing = acc.find(item => item.week === week);
    if (existing) {
      existing[t.type] += t.amount;
      existing.total += t.amount;
    } else {
      acc.push({
        week,
        income: t.type === 'income' ? t.amount : 0,
        expense: t.type === 'expense' ? t.amount : 0,
        total: t.amount
      });
    }
    return acc;
  }, [] as {week: string, income: number, expense: number, total: number}[])
  .sort((a, b) => a.week.localeCompare(b.week));

  function getWeekNumber(d: Date) {
    const date = new Date(d);
    date.setHours(0, 0, 0, 0);
    date.setDate(date.getDate() + 3 - (date.getDay() + 6) % 7);
    const week1 = new Date(date.getFullYear(), 0, 4);
    return 1 + Math.round(((date.getTime() - week1.getTime()) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
  }

  const handleImport = (importedTransactions: Transaction[]) => {
    setTransactions([...transactions, ...importedTransactions]);
    toast.success(`成功导入 ${importedTransactions.length} 条交易记录`);
  };

  // 导出数据为CSV
  const handleExport = () => {
    const headers = ['日期', '类型', '分类', '子分类', '金额', '备注', '标签'];
    const csvContent = Papa.unparse({
      fields: headers,
      data: transactions.map(t => ({
        日期: t.date,
        类型: t.type === 'income' ? '收入' : '支出',
        分类: t.category,
        子分类: t.subcategory,
        金额: t.amount,
        备注: t.note,
        标签: t.tags?.join(';') || ''
      }))
    });
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', formatExportFilename('交易记录', 'csv'));
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success('导出成功');
  };

  // 导出存档数据
  const handleExportBackup = () => {
    const backupData = {
      version: '1.0',
      createdAt: new Date().toISOString(),
      transactions: transactions
    };
    
    const dataStr = JSON.stringify(backupData, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', formatExportFilename('财务数据备份', 'json'));
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success('存档导出成功');
  };

  // 导入存档数据
  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const result = JSON.parse(event.target?.result as string);
        if (!validateTransactionData(result.transactions)) {
          toast.error('文件格式不正确');
          return;
        }

        setTransactions(result.transactions);
        toast.success(`成功导入 ${result.transactions.length} 条记录`);
      } catch (error) {
        toast.error('解析文件失败');
        console.error(error);
      }
    };
    reader.readAsText(file);

    // 重置input值，允许重复选择同一文件
    if (e.target) e.target.value = '';
  };

  // 添加标签
  const handleAddTag = (index: number) => {
    if (!newTag.trim()) return;
    
    const newTransactions = [...transactions];
    if (!newTransactions[index].tags) {
      newTransactions[index].tags = [];
    }
    
    if (!newTransactions[index].tags.includes(newTag.trim())) {
      newTransactions[index].tags.push(newTag.trim());
      setTransactions(newTransactions);
      toast.success('标签已添加');
      setNewTag('');
    }
  };

  // 删除标签
  const handleRemoveTag = (index: number, tagIndex: number) => {
    const newTransactions = [...transactions];
    newTransactions[index].tags.splice(tagIndex, 1);
    setTransactions(newTransactions);
    toast.success('标签已删除');
  };

  return (
    <Layout title="智能记账系统" showFooter={false}>
      <div className="pb-20 relative">
        {/* 添加记录模态框 */}
        <AnimatePresence>
          {showAddModal && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
              onClick={() => setShowAddModal(false)}
            >
              <motion.div 
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: -20, opacity: 0 }}
                transition={{ type: 'spring', damping: 25 }}
                className="bg-white dark:bg-gray-800 rounded-xl shadow-xl w-full max-w-md p-6"
                onClick={(e) => e.stopPropagation()}
              >
                <h2 className="text-xl font-bold mb-4">添加新记录</h2>
                
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">类型</label>
                  <div className="relative">
                    <select
                      value={newTransaction.type}
                      onChange={(e) => setNewTransaction({...newTransaction, type: e.target.value as 'income' | 'expense'})}
                      className="w-full px-3 py-2 border-2 border-blue-500 rounded-lg dark:bg-gray-700 appearance-none"
                    >
                      <option value="expense">支出</option>
                      <option value="income">收入</option>
                    </select>
                    <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                      <i className="fa-solid fa-chevron-down text-gray-400"></i>
                    </div>
                  </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">金额</label>
                      <input
                        type="number"
                        ref={amountInputRef}
                        value={newTransaction.amount}
                        onChange={(e) => setNewTransaction({...newTransaction, amount: Number(e.target.value)})}
                        className="w-full px-3 py-2 border rounded-lg dark:bg-gray-700"
                        placeholder="0"
                        autoFocus
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">分类</label>
                      <select
                        value={newTransaction.category}
                        onChange={(e) => setNewTransaction({
                          ...newTransaction, 
                          category: e.target.value,
                          subcategory: ''
                        })}
                        className="w-full px-3 py-2 border rounded-lg dark:bg-gray-700"
                      >
                        {Object.keys(CATEGORIES).map(cat => (
                          <option key={cat} value={cat}>{cat}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">子分类</label>
                      <select
                        value={newTransaction.subcategory}
                        onChange={(e) => setNewTransaction({...newTransaction, subcategory: e.target.value})}
                        className="w-full px-3 py-2 border rounded-lg dark:bg-gray-700"
                      >
                        <option value="">无子分类</option>
                        {CATEGORIES[newTransaction.category as keyof typeof CATEGORIES]?.map(sub => (
                          <option key={sub} value={sub}>{sub}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-1">日期</label>
                    <input
                      type="date"
                      value={newTransaction.date}
                      onChange={(e) => setNewTransaction({...newTransaction, date: e.target.value})}
                      className="w-full px-3 py-2 border rounded-lg dark:bg-gray-700"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-1">备注</label>
                    <input
                      type="text"
                      value={newTransaction.note}
                      onChange={(e) => setNewTransaction({...newTransaction, note: e.target.value})}
                      className="w-full px-3 py-2 border rounded-lg dark:bg-gray-700"
                      placeholder="可选"
                    />
                  </div>

               <div className="flex justify-end space-x-3 pt-4">
                <motion.button
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  取消
                </motion.button>
                <motion.button
                  onClick={() => {
                    if (newTransaction.amount <= 0) {
                      toast.error('请输入有效的金额');
                      return;
                    }
                    const transactionToAdd = {
                      ...newTransaction,
                      id: Date.now().toString()
                    };
                        setTransactions([...transactions, transactionToAdd]);
                        setShowAddModal(false);
                        setNewTransaction({
                          ...newTransaction,
                          amount: 0,
                          note: ''
                        });
                        toast.success('记录添加成功');
                      }}
                      className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg"
                      whileHover={{ scale: 1.03 }}
                      whileTap={{ scale: 0.97 }}
                    >
                      保存记录
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
        {/* 视图切换和筛选 */}
        <div className="flex flex-col md:flex-row justify-between mb-6 border-b dark:border-gray-700">
          <div className="flex">
            <button
              className={`px-4 py-2 font-medium ${activeView === 'transactions' ? 'text-blue-500 border-b-2 border-blue-500' : 'text-gray-500'}`}
              onClick={() => setActiveView('transactions')}
            >
              交易记录
            </button>
            <button
              className={`px-4 py-2 font-medium ${activeView === 'stats' ? 'text-blue-500 border-b-2 border-blue-500' : 'text-gray-500'}`}
              onClick={() => setActiveView('stats')}
            >
              统计分析
            </button>
          </div>
          {activeView === 'transactions' && (
            <div className="mt-2 md:mt-0">
              <select 
                className="px-3 py-1 border rounded-lg dark:bg-gray-700 dark:border-gray-600 text-sm"
                onChange={(e) => setFilterCategory(e.target.value)}
              >
                <option value="">所有分类</option>
                {Object.keys(CATEGORIES).map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
          )}
        </div>

          {activeView === 'transactions' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {filterCategory && (
                <div className="col-span-full flex items-center text-sm text-gray-500 dark:text-gray-400">
                  <i className="fa-solid fa-filter mr-2"></i>
                  当前筛选: {filterCategory}
                  <button 
                    onClick={() => setFilterCategory('')}
                    className="ml-2 text-blue-500 hover:text-blue-700"
                  >
                    <i className="fa-solid fa-times"></i>
                  </button>
                </div>
              )}
            {/* 交易记录列表 */}
            <div className="lg:col-span-2 bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold">交易记录</h2>
                 <div className="flex gap-3">
                   <WeChatImport onImport={handleImport} />
                   <div className="relative">
                     <button 
                       className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg flex items-center"
                       onClick={handleExport}
                     >
                       <i className="fa-solid fa-file-csv mr-2"></i>
                       导出表格
                     </button>
                   </div>
                   <div className="relative">
                     <button 
                       className="bg-purple-500 hover:bg-purple-600 text-white px-4 py-2 rounded-lg flex items-center"
                       onClick={handleExportBackup}
                     >
                       <i className="fa-solid fa-file-export mr-2"></i>
                       导出存档
                     </button>
                   </div>
                   <div className="relative">
                     <button 
                       className="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded-lg flex items-center"
                       onClick={() => document.getElementById('backup-import')?.click()}
                     >
                       <i className="fa-solid fa-file-import mr-2"></i>
                       导入存档
                     </button>
                     <input
                       id="backup-import"
                       type="file"
                       accept=".json"
                       onChange={handleImportBackup}
                       className="hidden"
                     />
                   </div>
                   <motion.button 
                    className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center"
                    onClick={() => {
                      setShowAddModal(true);
                    }}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <i className="fa-solid fa-plus mr-2"></i>
                    添加记录
                  </motion.button>
                </div>
              </div>
              
               <div className="space-y-3">
                 {filteredTransactions.length === 0 ? (
                   <motion.div 
                     initial={{ opacity: 0 }}
                     animate={{ opacity: 1 }}
                     className="text-center py-12"
                   >
                     <i className="fa-solid fa-wallet text-4xl text-gray-400 mb-4"></i>
                     <p className="text-gray-500">暂无交易记录</p>
                   </motion.div>
                 ) : (
                   filteredTransactions.map((transaction, index) => (
                     <motion.div
                       key={transaction.id}
                       initial={{ opacity: 0, y: 10 }}
                       animate={{ opacity: 1, y: 0 }}
                       transition={{ duration: 0.2 }}
                       className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4 group hover:shadow-md transition-shadow duration-200"
                     >
                       <div className="flex justify-between items-start">
                         <div className="flex-grow space-y-2">
                           <div className="flex flex-wrap items-center gap-2">
                             <select
                               value={transaction.category}
                               onChange={(e) => {
                                 const newTransactions = [...transactions];
                                 newTransactions[index].category = e.target.value;
                                 newTransactions[index].subcategory = '';
                                 setTransactions(newTransactions);
                                 toast.success('分类已更新');
                               }}
                               className="px-3 py-1 rounded-lg border border-gray-200 dark:border-gray-600 dark:bg-gray-700 focus:ring-2 focus:ring-blue-500 text-sm"
                             >
                               {Object.keys(CATEGORIES).map(cat => (
                                 <option key={cat} value={cat}>{cat}</option>
                               ))}
                             </select>
                             <select
                               value={transaction.subcategory}
                               onChange={(e) => {
                                 const newTransactions = [...transactions];
                                 newTransactions[index].subcategory = e.target.value;
                                 setTransactions(newTransactions);
                                 toast.success('子分类已更新');
                               }}
                               className="px-3 py-1 rounded-lg border border-gray-200 dark:border-gray-600 dark:bg-gray-700 focus:ring-2 focus:ring-blue-500 text-sm"
                             >
                               <option value="">无子分类</option>
                               {CATEGORIES[transaction.category as keyof typeof CATEGORIES]?.map(sub => (
                                 <option key={sub} value={sub}>{sub}</option>
                               ))}
                             </select>
                           </div>
                           
                           <div className="flex items-center gap-2">
                             <input
                               type="date"
                               value={transaction.date}
                               onChange={(e) => {
                                 const newTransactions = [...transactions];
                                 newTransactions[index].date = e.target.value;
                                 setTransactions(newTransactions);
                                 toast.success('日期已更新');
                               }}
                               className="px-3 py-1 rounded-lg border border-gray-200 dark:border-gray-600 dark:bg-gray-700 focus:ring-2 focus:ring-blue-500 text-sm"
                             />
                             <input
                               type="text"
                               value={transaction.note}
                               onChange={(e) => {
                                 const newTransactions = [...transactions];
                                 newTransactions[index].note = e.target.value;
                                 setTransactions(newTransactions);
                                 if (e.target.value) {
                                   toast.success('备注已更新');
                                 }
                               }}
                               placeholder="添加备注"
                               className="px-3 py-1 rounded-lg border border-gray-200 dark:border-gray-600 dark:bg-gray-700 focus:ring-2 focus:ring-blue-500 text-sm flex-grow"
                             />
                           </div>
                           
                           {/* 标签区域 */}
                           <div className="flex flex-wrap items-center gap-1">
                             {transaction.tags?.map((tag, tagIndex) => (
                               <motion.span 
                                 key={tagIndex}
                                 whileHover={{ scale: 1.05 }}
                                 className="inline-flex items-center bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 text-xs px-2 py-1 rounded-full"
                               >
                                 {tag}
                                 <button 
                                   onClick={() => handleRemoveTag(index, tagIndex)}
                                   className="ml-1 text-blue-500 hover:text-blue-700"
                                 >
                                   <i className="fa-solid fa-times text-xs"></i>
                                 </button>
                               </motion.span>
                             ))}
                             <div className="relative">
                               <input
                                 type="text"
                                 value={newTag}
                                 onChange={(e) => setNewTag(e.target.value)}
                                 onKeyPress={(e) => e.key === 'Enter' && handleAddTag(index)}
                                 placeholder="添加标签"
                                 className="text-xs px-2 py-1 rounded-full border border-gray-200 dark:border-gray-600 dark:bg-gray-700 w-24"
                               />
                               <button
                                 onClick={() => handleAddTag(index)}
                                 className="absolute right-1 top-1/2 transform -translate-y-1/2 text-xs text-blue-500"
                               >
                                 <i className="fa-solid fa-plus"></i>
                               </button>
                             </div>
                           </div>
                         </div>
                         
                         <div className="flex items-center gap-2">
                           <input
                             type="number"
                             value={transaction.amount}
                             onChange={(e) => {
                               const newTransactions = [...transactions];
                               newTransactions[index].amount = Number(e.target.value);
                               setTransactions(newTransactions);
                               toast.success('金额已更新');
                             }}
                             className={`w-24 px-3 py-1 rounded-lg border border-gray-200 dark:border-gray-600 dark:bg-gray-700 text-right font-bold ${
                               transaction.type === 'income' ? 'text-green-500' : 'text-red-500'
                             }`}
                           />
                           <motion.button
                             onClick={() => {
                               setTransactions(transactions.filter((_, i) => i !== index));
                               toast.success('交易记录已删除');
                             }}
                             whileHover={{ scale: 1.1 }}
                             whileTap={{ scale: 0.9 }}
                             className="text-red-500 hover:text-red-700"
                           >
                             <i className="fa-solid fa-trash"></i>
                           </motion.button>
                         </div>
                       </div>
                     </motion.div>
                   ))
                 )}
               </div>
            </div>
            
            {/* 统计面板 */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
              <h2 className="text-xl font-bold mb-6">统计概览</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                  className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg"
                >
                  <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">总收入</h3>
                  <p className="text-2xl font-bold text-green-500">
                    ¥{transactions
                      .filter(t => t.type === 'income')
                      .reduce((sum, t) => sum + t.amount, 0)
                      .toLocaleString('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </p>
                </motion.div>
                
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: 0.1 }}
                  className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg"
                >
                  <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">总支出</h3>
                  <p className="text-2xl font-bold text-red-500">
                    ¥{transactions
                      .filter(t => t.type === 'expense')
                      .reduce((sum, t) => sum + t.amount, 0)
                      .toLocaleString('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </p>
                </motion.div>
                
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: 0.2 }}
                  className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg"
                >
                  <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">净收入</h3>
                  <p className={`text-2xl font-bold ${
                    (transactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0) - 
                    transactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0)) >= 0 
                      ? 'text-green-500' : 'text-red-500'
                  }`}>
                    ¥{(transactions
                      .filter(t => t.type === 'income')
                      .reduce((sum, t) => sum + t.amount, 0) - 
                    transactions
                      .filter(t => t.type === 'expense')
                      .reduce((sum, t) => sum + t.amount, 0))
                      .toLocaleString('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </p>
                </motion.div>
              </div>
              
              <div className="mt-6 h-64">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">支出分类占比</h3>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={categoryData.slice(0, 6)}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      innerRadius={40}
                      paddingAngle={2}
                      dataKey="amount"
                      nameKey="category"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      animationBegin={200}
                      animationDuration={1000}
                      animationEasing="ease-out"
                    >
                      {categoryData.slice(0, 6).map((entry, index) => (
                        <Cell 
                          key={`cell-${index}`} 
                          fill={COLORS[index % COLORS.length]} 
                        />
                      ))}
                    </Pie>
                    <Tooltip 
                      formatter={(value) => [`¥${Number(value).toLocaleString('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, '']}
                      contentStyle={{
                        background: 'var(--bg-color)',
                        borderColor: 'var(--border-color)',
                        borderRadius: '0.5rem',
                        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                      }}
                    />
                    <Legend 
                      layout="horizontal" 
                      verticalAlign="bottom" 
                      align="center"
                      wrapperStyle={{
                        paddingTop: '1rem'
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {activeView === 'stats' && (
          <div className="space-y-6">
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
              <h2 className="text-xl font-bold mb-6">支出分类统计</h2>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={categoryData}
                    margin={{
                      top: 5,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="category" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="amount" name="金额(元)" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
              <h2 className="text-xl font-bold mb-6">支出子分类统计</h2>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={subcategoryData}
                    margin={{
                      top: 5,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="subcategory" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="amount" name="金额(元)" fill="#82ca9d" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
              <h2 className="text-xl font-bold mb-6">支出分类占比</h2>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={categoryData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="amount"
                      nameKey="category"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {categoryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
              <h2 className="text-xl font-bold mb-6">月度收支趋势</h2>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={monthlyData}
                    margin={{
                      top: 5,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="income" name="收入" fill="#82ca9d" />
                    <Bar dataKey="expense" name="支出" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
              <h2 className="text-xl font-bold mb-6">周收支趋势</h2>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={weeklyData}
                    margin={{
                      top: 5,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="week" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="income" name="收入" stroke="#82ca9d" />
                    <Line type="monotone" dataKey="expense" name="支出" stroke="#8884d8" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}