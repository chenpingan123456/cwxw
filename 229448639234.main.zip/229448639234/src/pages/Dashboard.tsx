import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from "framer-motion";
import { useTheme } from '@/hooks/useTheme';
import Layout from '@/components/Layout';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { useLocalStorage } from '@/hooks/useLocalStorage';


interface Transaction {
  id: string;
  amount: number;
  type: 'income' | 'expense';
  category: string;
  date: string;
  note: string;
  isRecurring: boolean;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

export default function Dashboard() {
  const navigate = useNavigate();
  const [transactions] = useLocalStorage<Transaction[]>('transactions', []);
  const { isDark } = useTheme();

  // 月度收支数据
  const monthlyData = transactions.reduce((acc, t) => {
    const month = t.date.split('-').slice(0, 2).join('-');
    const existing = acc.find(item => item.month === month);
    if (existing) {
      existing[t.type] += t.amount;
      existing.total += t.amount;
    } else {
      acc.push({
        month,
        income: t.type === 'income' ? t.amount : 0,
        expense: t.type === 'expense' ? t.amount : 0,
        total: t.amount
      });
    }
    return acc;
  }, [] as {month: string, income: number, expense: number, total: number}[])
  .sort((a, b) => a.month.localeCompare(b.month));

  // 支出分类数据
  const categoryData = transactions
    .filter(t => t.type === 'expense')
    .reduce((acc, t) => {
      const existing = acc.find(item => item.category === t.category);
      if (existing) {
        existing.amount += t.amount;
      } else {
        acc.push({ category: t.category, amount: t.amount });
      }
      return acc;
    }, [] as {category: string, amount: number}[])
    .sort((a, b) => b.amount - a.amount);

  // 关键指标
  const totalIncome = transactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);
  
  const totalExpense = transactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const netIncome = totalIncome - totalExpense;

  return (
    <Layout title="财务概览">
      <div className="space-y-6">
          {/* 关键指标卡片 */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <motion.div 
              className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">总收入</h3>
              <p className="text-2xl font-bold text-green-500 dark:text-green-400">¥{totalIncome.toFixed(2)}</p>
            </motion.div>
            <motion.div 
              className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">总支出</h3>
              <p className="text-2xl font-bold text-red-500 dark:text-red-400">¥{totalExpense.toFixed(2)}</p>
            </motion.div>
            <motion.div 
              className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.2 }}
            >
              <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">净收入</h3>
              <p className="text-2xl font-bold text-blue-500 dark:text-blue-400">
                ¥{netIncome.toFixed(2)}
              </p>
            </motion.div>
          </div>

          {/* 月度收支趋势 */}
          <motion.div 
            className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-xl font-bold mb-6">月度收支趋势</h2>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={monthlyData}
                  margin={{
                    top: 20,
                    right: 30,
                    left: 20,
                    bottom: 20,
                  }}
                >
                  <CartesianGrid 
                    strokeDasharray="3 3" 
                    stroke={useTheme().isDark ? '#4b5563' : '#e5e7eb'} 
                    opacity={0.3}
                  />
                  <XAxis 
                    dataKey="month" 
                    stroke={useTheme().isDark ? '#d1d5db' : '#4b5563'}
                    tick={{ 
                      fill: useTheme().isDark ? '#e5e7eb' : '#111827',
                      fontSize: 12
                    }}
                  />
                  <YAxis 
                    stroke={useTheme().isDark ? '#d1d5db' : '#4b5563'}
                    tick={{ 
                      fill: useTheme().isDark ? '#e5e7eb' : '#111827',
                      fontSize: 12
                    }}
                    tickFormatter={(value) => `¥${value.toLocaleString()}`}
                  />
                  <Tooltip 
                    contentStyle={{
                      background: useTheme().isDark ? 'rgb(31 41 55)' : 'rgb(255 255 255)',
                      borderColor: useTheme().isDark ? 'rgb(75 85 99)' : 'rgb(229 231 235)',
                      borderRadius: '0.75rem',
                      boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)',
                      padding: '0.75rem',
                      transition: 'all 0.2s ease-out'
                    }}
                    itemStyle={{
                      color: useTheme().isDark ? 'rgb(243 244 246)' : 'rgb(17 24 28)',
                      fontWeight: 500,
                      fontSize: '0.875rem'
                    }}
                    formatter={(value) => [`¥${Number(value).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}`, '']}
                    cursor={{
                      fill: useTheme().isDark ? 'rgba(75, 85, 99, 0.5)' : 'rgba(209, 213, 219, 0.5)',
                      strokeWidth: 2,
                      stroke: useTheme().isDark ? 'rgb(107 114 128)' : 'rgb(156 163 175)'
                    }}
                  />
                  <Legend 
                    wrapperStyle={{
                      paddingTop: '1rem'
                    }}
                    formatter={(value) => <span className="text-sm">{value}</span>}
                  />
                   <Bar 
                    dataKey="income" 
                    name="收入" 
                    fill={useTheme().isDark ? 'rgb(16 185 129)' : 'rgb(5 150 105)'}
                    animationBegin={100}
                    animationDuration={1500}
                    animationEasing="ease-out"
                    radius={[4, 4, 0, 0]}
                    className="hover:opacity-90 transition-opacity duration-200"
                  />
                  <Bar 
                    dataKey="expense" 
                    name="支出" 
                    fill={useTheme().isDark ? 'rgb(59 130 246)' : 'rgb(37 99 235)'}
                    animationBegin={300}
                    animationDuration={1500}
                    animationEasing="ease-out"
                    radius={[4, 4, 0, 0]}
                    className="hover:opacity-90 transition-opacity duration-200"
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </motion.div>

          {/* 支出分类占比 */}
           <motion.div 
             className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6"
             initial={{ opacity: 0 }}
             animate={{ opacity: 1 }}
             transition={{ duration: 0.5, delay: 0.2 }}
           >
             <h2 className="text-xl font-bold mb-6">支出分类占比</h2>
             <div className="h-80">
               <ResponsiveContainer width="100%" height="100%">
                 <PieChart>
                   <Pie
                     data={categoryData}
                     cx="50%"
                     cy="50%"
                     labelLine={false}
                     outerRadius={80}
                     innerRadius={40}
                     dataKey="amount"
                     nameKey="category"
                     label={({ name, percent }) => (
                        <text 
                          fill={isDark ? '#f3f4f6' : '#111827'}
                          fontSize="0.75rem"
                          fontWeight="500"
                       >
                         {`${name} ${(percent * 100).toFixed(0)}%`}
                       </text>
                     )}
                     animationBegin={200}
                     animationDuration={1500}
                     animationEasing="ease-out"
                   >
                     {categoryData.map((entry, index) => (
                       <Cell 
                         key={`cell-${index}`} 
                          fill={isDark ? [
                            '#3b82f6', '#10b981', '#f59e0b', 
                            '#ef4444', '#8b5cf6', '#ec4899'
                          ][index % 6] : [
                            '#2563eb', '#059669', '#d97706',
                            '#dc2626', '#7c3aed', '#db2777'
                          ][index % 6]}
                       />
                     ))}
                   </Pie>
                    <Tooltip 
                      contentStyle={{
                        background: useTheme().isDark ? 'rgb(31 41 55)' : 'rgb(255 255 255)',
                        borderColor: useTheme().isDark ? 'rgb(75 85 99)' : 'rgb(229 231 235)',
                        borderRadius: '0.75rem',
                        boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)',
                        padding: '0.75rem',
                        transition: 'all 0.2s ease-out'
                      }}
                      itemStyle={{
                        color: useTheme().isDark ? 'rgb(243 244 246)' : 'rgb(17 24 28)',
                        fontWeight: 500,
                        fontSize: '0.875rem'
                      }}
                      formatter={(value) => [`¥${Number(value).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}`, '']}
                    />
                   <Legend 
                     wrapperStyle={{
                       paddingTop: '1rem'
                     }}
                     formatter={(value) => <span className="text-sm">{value}</span>}
                   />
                 </PieChart>
               </ResponsiveContainer>
             </div>
           </motion.div>
      </div>
    </Layout>
  );
}