import { useState, useEffect } from 'react';
import { motion } from "framer-motion";
import { useNavigate } from 'react-router-dom';
import { useTheme } from '@/hooks/useTheme';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { toast } from 'sonner';
import { useLocalStorage } from '@/hooks/useLocalStorage';


interface BudgetItem {
  id: string;
  category: string;
  amount: number;
  used: number;
  period: 'weekly' | 'monthly' | 'yearly';
}

export default function Budget() {
  const navigate = useNavigate();
  const { isDark } = useTheme();
  const [budgets, setBudgets] = useLocalStorage<BudgetItem[]>('budgets', []);
  const [newBudget, setNewBudget] = useState<Omit<BudgetItem, 'id'>>({
    category: '',
    amount: 0,
    used: 0,
    period: 'monthly'
  });
  const [activeTab, setActiveTab] = useState<'list' | 'stats'>('list');

  const categories = [
    '餐饮', '交通', '娱乐', '购物', 
    '住房', '医疗', '教育', '其他'
  ];

  // 预算提醒
  useEffect(() => {
    budgets.forEach(budget => {
      const percentage = (budget.used / budget.amount) * 100;
      if (percentage > 80) {
        toast.warning(`预算提醒: ${budget.category} 已使用 ${percentage.toFixed(0)}%`);
      }
    });
  }, [budgets]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setNewBudget(prev => ({
      ...prev,
      [name]: name === 'amount' || name === 'used' ? Number(value) : value
    }));
  };

  const handleAddBudget = () => {
    if (!newBudget.category) {
      toast.error('请选择预算类别');
      return;
    }
    
    if (newBudget.amount <= 0) {
      toast.error('请输入有效的预算金额');
      return;
    }

    // 检查是否已存在相同类别的预算
    const existingBudget = budgets.find(b => b.category === newBudget.category);
    if (existingBudget) {
      toast.error('该类别预算已存在');
      return;
    }

    const newItem = {
      ...newBudget,
      id: Date.now().toString()
    };

    setBudgets(prev => [...prev, newItem]);
    toast.success('预算添加成功');
    setNewBudget({
      category: '',
      amount: 0,
      used: 0,
      period: 'monthly'
    });
  };

  const handleDeleteBudget = (id: string) => {
    setBudgets(prev => prev.filter(item => item.id !== id));
    toast.success('预算删除成功');
  };

  const calculateRemaining = (budget: BudgetItem) => {
    return budget.amount - budget.used;
  };

  const getProgressColor = (percentage: number) => {
    if (percentage < 50) return 'bg-green-500';
    if (percentage < 80) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  // 预算统计图表数据
  const budgetStats = budgets.map(budget => ({
    name: budget.category,
    预算: budget.amount,
    实际支出: budget.used,
    剩余: budget.amount - budget.used
  }));

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <header className="bg-white dark:bg-gray-800 shadow-sm py-4 px-6">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <button 
              onClick={() => navigate('/')}
              className="text-blue-500 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
            >
              <i className="fa-solid fa-arrow-left mr-2"></i>
              返回首页
            </button>
          </div>
          <h1 className="text-xl font-bold text-gray-800 dark:text-gray-100">预算管理</h1>
          <div className="w-8"></div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto py-8 px-4">
        {/* 标签切换 */}
        <div className="flex mb-6 border-b dark:border-gray-700">
          <button
            className={`px-4 py-2 font-medium ${activeTab === 'list' ? 'text-blue-500 dark:text-blue-400 border-b-2 border-blue-500 dark:border-blue-400' : 'text-gray-500 dark:text-gray-400'}`}
            onClick={() => setActiveTab('list')}
          >
            预算列表
          </button>
          <button
            className={`px-4 py-2 font-medium ${activeTab === 'stats' ? 'text-blue-500 dark:text-blue-400 border-b-2 border-blue-500 dark:border-blue-400' : 'text-gray-500 dark:text-gray-400'}`}
            onClick={() => setActiveTab('stats')}
          >
            统计分析
          </button>
        </div>

        {activeTab === 'list' ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* 新增预算表单 */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
              <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-6">新增预算</h2>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">分类</label>
                  <select
                    name="category"
                    value={newBudget.category}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border-2 border-blue-500 rounded-lg dark:bg-gray-700 dark:border-blue-400"
                  >
                    <option value="">选择分类</option>
                    {categories.map(category => (
                      <option key={category} value={category}>{category}</option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">预算金额</label>
                    <input
                      type="number"
                      name="amount"
                      value={newBudget.amount}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border-2 border-blue-500 rounded-lg dark:bg-gray-700 dark:border-blue-400"
                      placeholder="0"
                      min="0"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">周期</label>
                    <select
                      name="period"
                      value={newBudget.period}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border-2 border-blue-500 rounded-lg dark:bg-gray-700 dark:border-blue-400"
                    >
                      <option value="weekly">每周</option>
                      <option value="monthly">每月</option>
                      <option value="yearly">每年</option>
                    </select>
                  </div>
                </div>

                 <motion.button
                  onClick={handleAddBudget}
                  className="w-full bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded-lg transition-all"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  添加预算
                </motion.button>
              </div>
            </div>

            {/* 预算列表 */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
              <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-6">我的预算</h2>
              
              {budgets.length === 0 ? (
                <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                  <i className="fa-solid fa-coins text-4xl mb-2"></i>
                  <p>暂无预算计划</p>
                </div>
              ) : (
                <div className="space-y-6">
                  {budgets.map(budget => {
                    const remaining = calculateRemaining(budget);
                    const percentage = (budget.used / budget.amount) * 100;
                    const progressColor = getProgressColor(percentage);

                    return (
                      <div key={budget.id} className="border rounded-lg p-4 dark:border-gray-700">
                        <div className="flex justify-between items-center mb-2">
                          <h3 className="font-medium dark:text-gray-100">{budget.category}</h3>
                          <button 
                            onClick={() => handleDeleteBudget(budget.id)}
                            className="text-red-500 hover:text-red-700 dark:hover:text-red-400"
                          >
                            <i className="fa-solid fa-trash"></i>
                          </button>
                        </div>

                        <div className="mb-2">
                          <div className="flex justify-between text-sm mb-1 dark:text-gray-300">
                            <span>¥{budget.used.toFixed(2)} / ¥{budget.amount.toFixed(2)}</span>
                            <span>{percentage.toFixed(1)}%</span>
                          </div>
                          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                            <div 
                              className={`h-2.5 rounded-full ${progressColor}`} 
                              style={{ width: `${Math.min(percentage, 100)}%` }}
                            ></div>
                          </div>
                        </div>

                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600 dark:text-gray-400">周期: {{
                            weekly: '每周',
                            monthly: '每月',
                            yearly: '每年'
                          }[budget.period]}</span>
                          <span className={remaining >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}>
                            剩余: ¥{remaining.toFixed(2)}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
            <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-6">预算统计分析</h2>
            
            {budgets.length === 0 ? (
              <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                <i className="fa-solid fa-chart-pie text-4xl mb-2"></i>
                <p>暂无预算数据</p>
              </div>
            ) : (
              <div className="space-y-8">
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={budgetStats}
                        margin={{
                          top: 20,
                          right: 30,
                          left: 20,
                          bottom: 20,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#4b5563' : '#e5e7eb'} />
                         <XAxis 
                           dataKey="name" 
                           stroke={isDark ? '#9ca3af' : '#6b7280'}
                         />
                         <YAxis 
                           stroke={isDark ? '#9ca3af' : '#6b7280'}
                         />
                         <Tooltip 
                           formatter={(value, name) => [
                             `¥${value.toFixed(2)}`, 
                             name
                           ]}
                           contentStyle={{
                             background: isDark ? '#1f2937' : '#ffffff',
                             borderColor: isDark ? '#4b5563' : '#e5e7eb',
                             borderRadius: '0.5rem',
                            boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                          }}
                        />
                        <Legend />
                        <Bar 
                          dataKey="预算" 
                          fill="#3b82f6" 
                          name="预算金额"
                          animationBegin={100}
                          animationDuration={1000}
                          animationEasing="ease-out"
                        />
                        <Bar 
                          dataKey="实际支出" 
                          fill="#10b981" 
                          name="实际支出"
                          animationBegin={300}
                          animationDuration={1000}
                          animationEasing="ease-out"
                        />
                        <Bar 
                          dataKey="剩余" 
                          fill="#f59e0b" 
                          name="剩余预算"
                          animationBegin={500}
                          animationDuration={1000}
                          animationEasing="ease-out"
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {budgets.map(budget => {
                    const remaining = calculateRemaining(budget);
                    return (
                      <div key={budget.id} className="bg-gray-100 dark:bg-gray-700 rounded-lg p-4">
                        <h3 className="font-medium dark:text-gray-100">{budget.category}</h3>
                        <div className="mt-2 space-y-1 text-sm dark:text-gray-300">
                          <div className="flex justify-between">
                            <span>预算:</span>
                            <span>¥{budget.amount.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>已用:</span>
                            <span>¥{budget.used.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>剩余:</span>
                            <span className={remaining >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}>
                              ¥{remaining.toFixed(2)}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
