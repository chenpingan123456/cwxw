import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { motion } from 'framer-motion';
import Layout from '@/components/Layout';
import { toast } from 'sonner';

export default function FoodRoulette() {
  const navigate = useNavigate();
  const [foodOptions, setFoodOptions] = useLocalStorage<string[]>('foodOptions', [
    '拉面', '盖饭', '沙拉', '汉堡', '饺子', '火锅'
  ]);
  const [newFood, setNewFood] = useState('');
  const [selectedFood, setSelectedFood] = useState('');
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [spinCount, setSpinCount] = useState(0);

  // 预设食物选项
  const presetFoods = [
    '拉面', '盖饭', '沙拉', '汉堡', '饺子', '火锅',
    '寿司', '披萨', '烤肉', '炒饭', '汤面', '三明治'
  ];

  const handleAddFood = () => {
    if (!newFood.trim()) {
      toast.error('请输入食物名称');
      return;
    }
    
    if (foodOptions.includes(newFood.trim())) {
      toast.error('该食物选项已存在');
      return;
    }
    
    setFoodOptions(prev => [...prev, newFood.trim()]);
    toast.success(`"${newFood.trim()}" 已添加到选项`);
    setNewFood('');
    toast.success('食物选项添加成功');
  };

  const handleAddPresetFoods = () => {
    const newOptions = [...new Set([...foodOptions, ...presetFoods])];
    setFoodOptions(newOptions);
    toast.success(`已添加${newOptions.length - foodOptions.length}个预设食物选项`);
  };

  const handleRemoveFood = (index: number) => {
    setFoodOptions(prev => prev.filter((_, i) => i !== index));
    toast.success('食物选项已删除');
  };

  const spinRoulette = () => {
    if (foodOptions.length === 0) {
      toast.error('请先添加食物选项');
      return;
    }
    
    if (isSpinning) return;
    
    setIsSpinning(true);
    setSelectedFood('');
    setSpinCount(prev => prev + 1);
    
    const spins = 5 + Math.floor(Math.random() * 5);
    const degrees = spins * 360 + (Math.floor(Math.random() * 360));
    
    setRotation(prev => prev + degrees);
    
    setTimeout(() => {
      const segmentAngle = 360 / foodOptions.length;
      const normalizedRotation = degrees % 360;
      const selectedIndex = Math.floor(((360 - normalizedRotation) % 360) / segmentAngle);
      
      setIsSpinning(false);
      setSelectedFood(foodOptions[selectedIndex]);
      toast.success(`今日推荐: ${foodOptions[selectedIndex]}`);
    }, 4000);
  };

  // 重置转盘
  const resetRoulette = () => {
    setRotation(0);
    setSelectedFood('');
    toast.success('转盘已重置');
  };

  return (
    <Layout title="打工人吃什么" showBack>
      <div className="space-y-6">
        {/* 食物选项管理 */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
          <h2 className="text-xl font-semibold mb-4">食物选项 ({foodOptions.length})</h2>
          
          <div className="flex gap-2 mb-4">
            <input
              type="text"
              value={newFood}
              onChange={(e) => setNewFood(e.target.value)}
              placeholder="添加食物选项"
              className="flex-grow px-4 py-2 border rounded-lg dark:bg-gray-700 dark:border-gray-600"
              onKeyPress={(e) => e.key === 'Enter' && handleAddFood()}
            />
            <motion.button
              onClick={handleAddFood}
              className="bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded-lg"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              添加
            </motion.button>
            <motion.button
              onClick={handleAddPresetFoods}
              className="bg-purple-500 hover:bg-purple-600 text-white font-medium py-2 px-4 rounded-lg"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              添加预设
            </motion.button>
          </div>
          
          <div className="flex flex-wrap gap-2 mb-4">
            {foodOptions.map((food, index) => (
              <motion.div
                key={index}
                className="flex items-center bg-gray-100 dark:bg-gray-700 px-3 py-1 rounded-full"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <span className="mr-2">{food}</span>
                <button 
                  onClick={() => handleRemoveFood(index)}
                  className="text-red-500 hover:text-red-700"
                >
                  <i className="fa-solid fa-times text-sm"></i>
                </button>
              </motion.div>
            ))}
          </div>
        </div>
        
        {/* 转盘区域 */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
          <h2 className="text-xl font-semibold mb-4">今日吃什么</h2>
          
          <div className="flex flex-col items-center">
               <div className="relative w-72 h-72 mb-6">
                 {/* 转盘 */}
                 <motion.div
                   className="absolute inset-0 rounded-full border-8 border-blue-500 overflow-hidden shadow-xl"
                   animate={{ rotate: rotation }}
                   transition={{ 
                     duration: 4,
                     ease: [0.2, 0.8, 0.4, 1] 
                   }}
                   style={{
                     background: `conic-gradient(${foodOptions.map((_, i) => {
                       const hue = (i * (360 / foodOptions.length));
                       return `hsl(${hue}, 80%, 70%) ${i * (360 / foodOptions.length)}deg ${(i + 1) * (360 / foodOptions.length)}deg`;
                     }).join(', ')})`,
                     boxShadow: '0 10px 25px rgba(0,0,0,0.1)'
                   }}
                 >
                   {/* 食物选项 */}
                   {foodOptions.map((food, i) => {
                     const hue = (i * (360 / foodOptions.length));
                     return (
                       <motion.div 
                         key={i}
                         className="absolute w-24 h-10 flex items-center justify-center text-base font-medium"
                         style={{
                           top: '50%',
                           left: '50%',
                           transform: `rotate(${i * (360 / foodOptions.length)}deg) translateX(100px) rotate(${-i * (360 / foodOptions.length)}deg)`,
                           transformOrigin: 'left center',
                           color: `hsl(${hue}, 80%, 20%)`,
                           backgroundColor: `hsl(${hue}, 80%, 95%)`,
                           border: `1px solid hsl(${hue}, 80%, 80%)`,
                           borderRadius: '8px',
                           display: 'flex',
                           alignItems: 'center',
                           justifyContent: 'center',
                           textAlign: 'center',
                           lineHeight: '1.2',
                           fontSize: '0.9rem',
                           padding: '0 5px',
                           wordBreak: 'keep-all',
                           whiteSpace: 'nowrap',
                           fontFamily: 'sans-serif',
                           fontWeight: 'bold',
                           textShadow: '0 1px 2px rgba(0,0,0,0.1)',
                           transformStyle: 'preserve-3d',
                           backfaceVisibility: 'hidden'
                         }}
                         whileHover={{ scale: 1.1 }}
                       >
                         {food}
                       </motion.div>
                     );
                   })}
                 </motion.div>
              
              {/* 指针 */}
              <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-12 border-r-12 border-b-24 border-l-transparent border-r-transparent border-b-red-600 z-10 shadow-lg"></div>
              <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-6 h-6 bg-red-600 rounded-full z-20 shadow-md"></div>
            </div>
            
            <div className="flex gap-4">
              <motion.button
                onClick={spinRoulette}
                className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-medium py-3 px-6 rounded-lg text-lg shadow-md"
                whileHover={{ scale: 1.05, boxShadow: "0 5px 15px rgba(59, 130, 246, 0.4)" }}
                whileTap={{ scale: 0.95 }}
                disabled={isSpinning || foodOptions.length === 0}
              >
                {isSpinning ? (
                  <>
                    <i className="fa-solid fa-spinner fa-spin mr-2"></i>
                    旋转中...
                  </>
                ) : (
                  <>
                    <i className="fa-solid fa-rotate mr-2"></i>
                    开始选择
                  </>
                )}
              </motion.button>
              
              <motion.button
                onClick={resetRoulette}
                className="bg-gray-500 hover:bg-gray-600 text-white font-medium py-3 px-6 rounded-lg text-lg shadow-md"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                disabled={isSpinning}
              >
                <i className="fa-solid fa-rotate-left mr-2"></i>
                重置转盘
              </motion.button>
            </div>
            
            {selectedFood && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-6 text-2xl font-bold bg-gradient-to-r from-orange-500 to-pink-500 text-white px-6 py-2 rounded-full shadow-lg"
              >
                <i className="fa-solid fa-utensils mr-2"></i>
                今天吃: {selectedFood}
              </motion.div>
            )}
            
            {spinCount > 0 && (
              <div className="mt-4 text-sm text-gray-500 dark:text-gray-400">
                已选择 {spinCount} 次
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}