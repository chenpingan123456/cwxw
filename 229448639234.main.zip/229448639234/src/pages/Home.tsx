import { useNavigate } from "react-router-dom";
import { useTheme } from "@/hooks/useTheme";
import { motion } from "framer-motion";

export default function Home() {
  const navigate = useNavigate();
  const { isDark, toggleTheme } = useTheme();

  const features = [
      {
        title: "打工人吃什么",
        description: "自定义食物选项，随机选择今日午餐",
        icon: "fa-solid fa-utensils",
        color: "bg-orange-500",
        path: "/food-roulette"
      },
      {
        title: "记账管理",
        description: "记录收支情况，分类管理消费，设置周期性账单",
        icon: "fa-solid fa-wallet",
        color: "bg-green-500",
        path: "/accounting"
      },
      {
        title: "预算管理",
        description: "设置消费预算，跟踪预算执行情况",
        icon: "fa-solid fa-chart-pie",
        color: "bg-purple-500",
        path: "/budget"
      },
      {
        title: "财务概览",
        description: "查看财务数据总览和趋势分析",
        icon: "fa-solid fa-chart-line",
        color: "bg-blue-500",
        path: "/dashboard"
      },


  ];

  return (
    <div className={`min-h-screen flex flex-col font-roboto ${isDark ? 'bg-gray-900 text-gray-100' : 'bg-gray-50 text-gray-800'}`}>
      {/* 简约导航栏 */}
      <header className={`${isDark ? 'bg-gray-800/90 text-gray-100' : 'bg-white/90 text-gray-800'} backdrop-blur-sm py-4 px-6 sticky top-0 z-50 border-b ${isDark ? 'border-gray-700' : 'border-gray-100'}`}>
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className={`w-9 h-9 rounded-full bg-gradient-to-br ${isDark ? 'from-blue-500 to-blue-700' : 'from-blue-400 to-blue-600'} flex items-center justify-center text-white shadow-sm`}>
              <i className="fa-solid fa-wallet text-lg"></i>
            </div>
            <h1 className="text-xl font-medium">财务助手</h1>
          </div>
          <div className="flex items-center space-x-4">
             <button 
              onClick={toggleTheme}
              className={`p-2 rounded-lg ${isDark ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-200 hover:bg-gray-300'} transition-colors duration-200`}
              aria-label={`切换至${isDark ? '亮色' : '暗色'}主题`}
            >
              <i className={`fa-solid ${isDark ? 'fa-sun text-yellow-300' : 'fa-moon text-gray-600'}`}></i>
            </button>
            <button className="md:hidden">
              <i className="fa-solid fa-bars text-lg"></i>
            </button>
          </div>
        </div>
      </header>

      {/* 主内容 */}
      <main className="flex-grow py-12 px-4">
        <div className="max-w-6xl mx-auto">
          {/* 欢迎区域 */}
          <section className="mb-16 text-center">
            <h2 className="text-3xl font-light mb-4 tracking-tight">掌控您的财务状况</h2>
            <p className={`${isDark ? 'text-gray-400' : 'text-gray-500'} max-w-2xl mx-auto leading-relaxed`}>
              简约优雅的财务管理工具，帮助您轻松规划财务未来
            </p>
          </section>

          {/* 优雅功能卡片 */}
          <section className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
            {features.map((feature, index) => (
              <div 
                key={index}
                onClick={() => navigate(feature.path)}
                className={`${isDark ? 'bg-gray-800 border-gray-700 hover:shadow-lg' : 'bg-white border-gray-100 hover:shadow-md'} rounded-xl shadow-sm transition-all duration-300 cursor-pointer border overflow-hidden group`}
              >
                <div className="p-6">
                  <div className="flex items-center mb-4">
                    <div className={`w-10 h-10 rounded-lg ${feature.color} flex items-center justify-center text-white mr-3 transition-all duration-300 group-hover:scale-110`}>
                      <i className={`${feature.icon} text-lg`}></i>
                    </div>
                    <h3 className="text-lg font-medium">{feature.title}</h3>
                  </div>
                  <p className={`${isDark ? 'text-gray-400' : 'text-gray-500'} text-sm mb-5`}>{feature.description}</p>
                  <div className={`${isDark ? 'text-blue-400' : 'text-blue-500'} text-sm font-medium flex items-center opacity-0 group-hover:opacity-100 transition-opacity duration-300`}>
                    开始使用 <i className="fa-solid fa-arrow-right ml-2"></i>
                  </div>
                </div>
              </div>
            ))}
          </section>





        </div>
      </main>

      {/* 简约页脚 */}
      <footer className={`${isDark ? 'bg-gray-800/90 border-gray-700' : 'bg-white/90 border-gray-100'} backdrop-blur-sm py-6 px-6 border-t`}>
        <div className="max-w-6xl mx-auto text-center">
          <p className={`${isDark ? 'text-gray-500' : 'text-gray-400'} text-xs`}>© 2025 财务助手. 保留所有权利.</p>
        </div>
      </footer>
    </div>
  );
}