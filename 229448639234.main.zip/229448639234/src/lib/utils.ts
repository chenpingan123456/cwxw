import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import Papa from 'papaparse'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// 验证JSON数据格式
export function validateTransactionData(data: any): boolean {
  if (!Array.isArray(data)) return false
  
  const requiredFields = ['id', 'amount', 'type', 'category', 'date']
  return data.every(item => {
    return requiredFields.every(field => field in item)
  })
}

// 格式化导出文件名
export function formatExportFilename(prefix: string, ext: string): string {
  const date = new Date().toISOString().split('T')[0]
  return `${prefix}_${date}.${ext}`
}
